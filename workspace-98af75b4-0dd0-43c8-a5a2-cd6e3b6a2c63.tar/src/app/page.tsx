'use client'

import { useState, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import Image from 'next/image'
import { 
  GraduationCap, 
  BookOpen, 
  Users, 
  Trophy, 
  Calendar, 
  ChevronRight, 
  MapPin, 
  Phone, 
  Mail, 
  Clock,
  Menu,
  X,
  ArrowRight,
  Star,
  Award,
  Target,
  Lightbulb,
  Heart,
  Globe,
  ChevronUp,
  Facebook,
  Instagram,
  Youtube,
  Twitter,
  Building,
  Library,
  Computer,
  Dumbbell,
  Microscope,
  Music,
  Palette
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'

// Animation variants
const fadeInUp = {
  initial: { opacity: 0, y: 60 },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 0.6 }
}

const staggerContainer = {
  animate: {
    transition: {
      staggerChildren: 0.1
    }
  }
}

// Navigation Component
function Navbar() {
  const [isScrolled, setIsScrolled] = useState(false)
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false)

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50)
    }
    window.addEventListener('scroll', handleScroll)
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  const navLinks = [
    { href: '#beranda', label: 'Beranda' },
    { href: '#tentang', label: 'Tentang' },
    { href: '#program', label: 'Program' },
    { href: '#fasilitas', label: 'Fasilitas' },
    { href: '#berita', label: 'Berita' },
    { href: '#kontak', label: 'Kontak' },
  ]

  const scrollToSection = (href: string) => {
    const element = document.querySelector(href)
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' })
    }
    setIsMobileMenuOpen(false)
  }

  return (
    <motion.nav
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled 
          ? 'bg-white/95 backdrop-blur-md shadow-lg' 
          : 'bg-transparent'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 md:h-20">
          {/* Logo */}
          <motion.div 
            className="flex items-center gap-3"
            whileHover={{ scale: 1.02 }}
          >
            <div className={`w-10 h-10 md:w-12 md:h-12 rounded-full flex items-center justify-center ${
              isScrolled ? 'bg-emerald-600' : 'bg-white'
            }`}>
              <GraduationCap className={`w-6 h-6 md:w-7 md:h-7 ${
                isScrolled ? 'text-white' : 'text-emerald-600'
              }`} />
            </div>
            <div>
              <h1 className={`font-bold text-lg md:text-xl ${
                isScrolled ? 'text-gray-900' : 'text-white'
              }`}>
                SMAN 10
              </h1>
              <p className={`text-xs ${
                isScrolled ? 'text-gray-500' : 'text-white/80'
              }`}>
                Kota Depok
              </p>
            </div>
          </motion.div>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center gap-1">
            {navLinks.map((link) => (
              <button
                key={link.href}
                onClick={() => scrollToSection(link.href)}
                className={`px-4 py-2 rounded-lg text-sm font-medium transition-all hover:scale-105 ${
                  isScrolled 
                    ? 'text-gray-700 hover:text-emerald-600 hover:bg-emerald-50' 
                    : 'text-white/90 hover:text-white hover:bg-white/10'
                }`}
              >
                {link.label}
              </button>
            ))}
          </div>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            className={`md:hidden p-2 rounded-lg ${
              isScrolled ? 'text-gray-700' : 'text-white'
            }`}
          >
            {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="md:hidden bg-white border-t"
          >
            <div className="px-4 py-4 space-y-2">
              {navLinks.map((link) => (
                <button
                  key={link.href}
                  onClick={() => scrollToSection(link.href)}
                  className="block w-full text-left px-4 py-3 rounded-lg text-gray-700 hover:bg-emerald-50 hover:text-emerald-600 transition-colors"
                >
                  {link.label}
                </button>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.nav>
  )
}

// Hero Section
function HeroSection() {
  return (
    <section id="beranda" className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background Image */}
      <div className="absolute inset-0">
        <Image
          src="/images/hero-school.png"
          alt="SMAN 10 Kota Depok"
          fill
          className="object-cover"
          priority
        />
        <div className="absolute inset-0 bg-gradient-to-r from-emerald-900/90 via-emerald-800/80 to-teal-700/70" />
      </div>

      {/* Animated Background Pattern */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute inset-0" style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='0.4'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`,
        }} />
      </div>

      {/* Floating Shapes */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <motion.div
          animate={{ 
            y: [0, -20, 0],
            rotate: [0, 5, 0]
          }}
          transition={{ duration: 6, repeat: Infinity }}
          className="absolute top-20 left-10 w-32 h-32 bg-white/10 rounded-full blur-xl"
        />
        <motion.div
          animate={{ 
            y: [0, 20, 0],
            rotate: [0, -5, 0]
          }}
          transition={{ duration: 8, repeat: Infinity }}
          className="absolute bottom-20 right-10 w-40 h-40 bg-teal-400/20 rounded-full blur-xl"
        />
      </div>

      {/* Content */}
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="space-y-6"
        >
          {/* Badge */}
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.2 }}
          >
            <Badge className="bg-white/20 text-white border-white/30 px-4 py-2 text-sm backdrop-blur-sm">
              <Star className="w-4 h-4 mr-2" />
              Sekolah Unggulan Kota Depok
            </Badge>
          </motion.div>

          {/* Title */}
          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="text-4xl md:text-6xl lg:text-7xl font-bold text-white leading-tight"
          >
            SMAN 10
            <span className="block text-emerald-200">Kota Depok</span>
          </motion.h1>

          {/* Tagline */}
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="text-lg md:text-xl lg:text-2xl text-emerald-100 max-w-3xl mx-auto"
          >
            Membentuk Generasi Unggul, Berkarakter, dan Berdaya Saing Global
          </motion.p>

          {/* CTA Buttons */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
            className="flex flex-col sm:flex-row gap-4 justify-center pt-4"
          >
            <Button 
              size="lg"
              className="bg-white text-emerald-700 hover:bg-emerald-50 px-8 py-6 text-lg font-semibold rounded-xl shadow-lg hover:shadow-xl transition-all group"
              onClick={() => document.querySelector('#tentang')?.scrollIntoView({ behavior: 'smooth' })}
            >
              Tentang Kami
              <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </Button>
            <Button 
              size="lg"
              variant="outline"
              className="border-2 border-white text-white hover:bg-white/10 px-8 py-6 text-lg font-semibold rounded-xl backdrop-blur-sm"
              onClick={() => document.querySelector('#kontak')?.scrollIntoView({ behavior: 'smooth' })}
            >
              Hubungi Kami
            </Button>
          </motion.div>
        </motion.div>

        {/* Stats */}
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.7 }}
          className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-8 mt-16 md:mt-20"
        >
          {[
            { icon: Users, value: '1,500+', label: 'Siswa Aktif' },
            { icon: GraduationCap, value: '100+', label: 'Guru Profesional' },
            { icon: Trophy, value: '50+', label: 'Prestasi' },
            { icon: Building, value: '25+', label: 'Tahun Berdiri' },
          ].map((stat, index) => (
            <motion.div
              key={index}
              whileHover={{ scale: 1.05 }}
              className="bg-white/10 backdrop-blur-sm rounded-2xl p-4 md:p-6 border border-white/20"
            >
              <stat.icon className="w-8 h-8 md:w-10 md:h-10 text-emerald-200 mx-auto mb-2" />
              <p className="text-2xl md:text-3xl font-bold text-white">{stat.value}</p>
              <p className="text-emerald-200 text-sm md:text-base">{stat.label}</p>
            </motion.div>
          ))}
        </motion.div>
      </div>

      {/* Scroll Indicator */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1 }}
        className="absolute bottom-8 left-1/2 -translate-x-1/2"
      >
        <motion.div
          animate={{ y: [0, 10, 0] }}
          transition={{ duration: 2, repeat: Infinity }}
          className="w-6 h-10 rounded-full border-2 border-white/50 flex justify-center pt-2"
        >
          <div className="w-1.5 h-3 bg-white/50 rounded-full" />
        </motion.div>
      </motion.div>
    </section>
  )
}

// About Section
function AboutSection() {
  return (
    <section id="tentang" className="py-20 md:py-28 bg-gradient-to-b from-gray-50 to-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial="initial"
          whileInView="animate"
          viewport={{ once: true }}
          variants={staggerContainer}
          className="grid lg:grid-cols-2 gap-12 items-center"
        >
          {/* Image Side */}
          <motion.div 
            variants={fadeInUp}
            className="relative"
          >
            <div className="relative rounded-3xl overflow-hidden shadow-2xl">
              <div className="aspect-[4/3] relative">
                <Image
                  src="/images/about-campus.png"
                  alt="Kampus SMAN 10 Kota Depok"
                  fill
                  className="object-cover"
                />
              </div>
            </div>
            {/* Floating Cards */}
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.3 }}
              className="absolute -bottom-6 -left-6 bg-white rounded-2xl shadow-xl p-4 hidden md:block"
            >
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-emerald-100 rounded-xl flex items-center justify-center">
                  <Award className="w-6 h-6 text-emerald-600" />
                </div>
                <div>
                  <p className="font-bold text-gray-900">Akreditasi A</p>
                  <p className="text-sm text-gray-500">Terakreditasi</p>
                </div>
              </div>
            </motion.div>
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.4 }}
              className="absolute -top-6 -right-6 bg-white rounded-2xl shadow-xl p-4 hidden md:block"
            >
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-teal-100 rounded-xl flex items-center justify-center">
                  <Trophy className="w-6 h-6 text-teal-600" />
                </div>
                <div>
                  <p className="font-bold text-gray-900">50+ Prestasi</p>
                  <p className="text-sm text-gray-500">Regional & Nasional</p>
                </div>
              </div>
            </motion.div>
          </motion.div>

          {/* Content Side */}
          <motion.div variants={fadeInUp}>
            <Badge className="bg-emerald-100 text-emerald-700 mb-4">Tentang Kami</Badge>
            <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-gray-900 mb-6 leading-tight">
              Mencetak Generasi <span className="text-emerald-600">Unggul</span> dan Berkarakter
            </h2>
            <p className="text-gray-600 text-lg mb-6 leading-relaxed">
              SMAN 10 Kota Depok merupakan sekolah menengah atas yang berkomitmen untuk memberikan pendidikan berkualitas dengan mengedepankan nilai-nilai karakter, inovasi, dan prestasi.
            </p>
            <p className="text-gray-600 mb-8 leading-relaxed">
              Dengan dukungan tenaga pendidik profesional dan fasilitas modern, kami berupaya menciptakan lingkungan belajar yang kondusif untuk mengembangkan potensi setiap siswa.
            </p>

            {/* Features */}
            <div className="grid sm:grid-cols-2 gap-4">
              {[
                { icon: Target, title: 'Visi & Misi', desc: 'Menghasilkan lulusan berkualitas' },
                { icon: Lightbulb, title: 'Inovatif', desc: 'Pembelajaran modern & kreatif' },
                { icon: Heart, title: 'Berkarakter', desc: 'Membentuk nilai-nilai luhur' },
                { icon: Globe, title: 'Bersaing Global', desc: 'Siap menghadapi tantangan' },
              ].map((feature, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.1 }}
                  className="flex items-start gap-3 p-3 rounded-xl hover:bg-gray-50 transition-colors"
                >
                  <div className="w-10 h-10 bg-emerald-100 rounded-lg flex items-center justify-center flex-shrink-0">
                    <feature.icon className="w-5 h-5 text-emerald-600" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-900">{feature.title}</h4>
                    <p className="text-sm text-gray-500">{feature.desc}</p>
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </motion.div>
      </div>
    </section>
  )
}

// Programs Section
function ProgramsSection() {
  const programs = [
    {
      icon: BookOpen,
      title: 'Kurikulum Merdeka',
      desc: 'Implementasi kurikulum terbaru yang memberikan kebebasan belajar dan mengembangkan potensi siswa secara optimal.',
      color: 'emerald'
    },
    {
      icon: Microscope,
      title: 'Program MIPA',
      desc: 'Fokus pada pengembangan kemampuan analitis dan saintifik dengan laboratorium lengkap dan praktikum intensif.',
      color: 'teal'
    },
    {
      icon: Globe,
      title: 'Program IPS',
      desc: 'Membentuk pemahaman sosial, ekonomi, dan geografi dengan pendekatan kontekstual dan studi kasus.',
      color: 'cyan'
    },
    {
      icon: Trophy,
      title: 'Klub Prestasi',
      desc: 'Berbagai kegiatan ekstrakurikuler untuk mengembangkan bakat dan meraih prestasi di tingkat nasional.',
      color: 'amber'
    },
    {
      icon: Users,
      title: 'OSIS & MPK',
      desc: 'Wadah kepemimpinan siswa untuk mengembangkan soft skills dan organisasi.',
      color: 'purple'
    },
    {
      icon: Music,
      title: 'Seni & Budaya',
      desc: 'Pengembangan kreativitas melalui paduan suara, band, tari tradisional, dan teater.',
      color: 'rose'
    },
  ]

  const colorClasses: Record<string, { bg: string; icon: string }> = {
    emerald: { bg: 'bg-emerald-100', icon: 'text-emerald-600' },
    teal: { bg: 'bg-teal-100', icon: 'text-teal-600' },
    cyan: { bg: 'bg-cyan-100', icon: 'text-cyan-600' },
    amber: { bg: 'bg-amber-100', icon: 'text-amber-600' },
    purple: { bg: 'bg-purple-100', icon: 'text-purple-600' },
    rose: { bg: 'bg-rose-100', icon: 'text-rose-600' },
  }

  return (
    <section id="program" className="py-20 md:py-28 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <Badge className="bg-emerald-100 text-emerald-700 mb-4">Program Kami</Badge>
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-gray-900 mb-4">
            Program Unggulan
          </h2>
          <p className="text-gray-600 text-lg max-w-2xl mx-auto">
            Berbagai program unggulan yang dirancang untuk mengembangkan potensi siswa secara menyeluruh
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {programs.map((program, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              whileHover={{ y: -5 }}
            >
              <Card className="h-full border border-gray-100 hover:border-emerald-200 hover:shadow-xl transition-all duration-300 overflow-hidden group">
                <CardContent className="p-6">
                  <div className={`w-14 h-14 ${colorClasses[program.color].bg} rounded-2xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform`}>
                    <program.icon className={`w-7 h-7 ${colorClasses[program.color].icon}`} />
                  </div>
                  <h3 className="text-xl font-bold text-gray-900 mb-2">{program.title}</h3>
                  <p className="text-gray-600 leading-relaxed">{program.desc}</p>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}

// Facilities Section
function FacilitiesSection() {
  const facilities = [
    { icon: Library, name: 'Perpustakaan Digital', desc: 'Koleksi 10,000+ buku dan akses e-resources' },
    { icon: Computer, name: 'Lab Komputer', desc: 'Lab modern dengan 60 unit komputer terbaru' },
    { icon: Microscope, name: 'Lab IPA', desc: 'Laboratorium Fisika, Kimia, dan Biologi lengkap' },
    { icon: Dumbbell, name: 'Lapangan Olahraga', desc: 'Lapangan futsal, basket, voli, dan atletik' },
    { icon: Palette, name: 'Ruang Seni', desc: 'Studio musik, tari, dan seni rupa' },
    { icon: Building, name: 'Ruang Kelas AC', desc: '36 ruang kelas ber-AC dengan smart TV' },
  ]

  return (
    <section id="fasilitas" className="py-20 md:py-28 bg-gradient-to-b from-gray-50 to-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <Badge className="bg-teal-100 text-teal-700 mb-4">Fasilitas</Badge>
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-gray-900 mb-4">
            Fasilitas Modern
          </h2>
          <p className="text-gray-600 text-lg max-w-2xl mx-auto">
            Dilengkapi dengan fasilitas modern untuk menunjang proses belajar mengajar
          </p>
        </motion.div>

        <div className="grid grid-cols-2 md:grid-cols-3 gap-4 md:gap-6">
          {facilities.map((facility, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.05 }}
              whileHover={{ scale: 1.02 }}
              className="bg-white rounded-2xl p-5 md:p-6 shadow-sm border border-gray-100 hover:shadow-lg hover:border-emerald-200 transition-all group cursor-pointer"
            >
              <div className="w-12 h-12 md:w-14 md:h-14 bg-gradient-to-br from-emerald-500 to-teal-500 rounded-xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                <facility.icon className="w-6 h-6 md:w-7 md:h-7 text-white" />
              </div>
              <h3 className="font-bold text-gray-900 mb-1 md:mb-2 text-sm md:text-base">{facility.name}</h3>
              <p className="text-gray-500 text-xs md:text-sm hidden sm:block">{facility.desc}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}

// News Section
function NewsSection() {
  const news = [
    {
      date: '15 Jan 2025',
      title: 'Penerimaan Peserta Didik Baru 2025/2026',
      desc: 'Pendaftaran PPDB SMAN 10 Kota Depok telah dibuka. Segera daftarkan diri Anda!',
      badge: 'Terbaru',
      badgeColor: 'bg-red-500',
      image: '/images/news/ppdb.png'
    },
    {
      date: '10 Jan 2025',
      title: 'Juara 1 Olimpiade Sains Nasional',
      desc: 'Siswa SMAN 10 berhasil meraih medali emas di OSN bidang Matematika.',
      badge: 'Prestasi',
      badgeColor: 'bg-amber-500',
      image: '/images/news/olympiad.png'
    },
    {
      date: '5 Jan 2025',
      title: 'Workshop Kewirausahaan Digital',
      desc: 'Kegiatan workshop untuk membekali siswa dengan skill bisnis digital.',
      badge: 'Kegiatan',
      badgeColor: 'bg-emerald-500',
      image: '/images/news/workshop.png'
    },
  ]

  return (
    <section id="berita" className="py-20 md:py-28 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="flex flex-col md:flex-row md:items-end md:justify-between mb-12"
        >
          <div>
            <Badge className="bg-emerald-100 text-emerald-700 mb-4">Berita & Pengumuman</Badge>
            <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-gray-900">
              Kabar Terbaru
            </h2>
          </div>
          <Button variant="outline" className="mt-4 md:mt-0 border-emerald-200 text-emerald-700 hover:bg-emerald-50">
            Lihat Semua
            <ChevronRight className="w-4 h-4 ml-1" />
          </Button>
        </motion.div>

        <div className="grid md:grid-cols-3 gap-6">
          {news.map((item, index) => (
            <motion.article
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              whileHover={{ y: -5 }}
              className="group cursor-pointer"
            >
              <Card className="overflow-hidden border border-gray-100 hover:shadow-xl hover:border-emerald-200 transition-all h-full">
                <div className="aspect-video relative overflow-hidden">
                  <Image
                    src={item.image}
                    alt={item.title}
                    fill
                    className="object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/30 to-transparent" />
                  <Badge className={`absolute top-4 left-4 ${item.badgeColor} text-white`}>
                    {item.badge}
                  </Badge>
                </div>
                <CardContent className="p-5">
                  <p className="text-sm text-gray-500 mb-2">{item.date}</p>
                  <h3 className="font-bold text-gray-900 mb-2 group-hover:text-emerald-600 transition-colors line-clamp-2">
                    {item.title}
                  </h3>
                  <p className="text-gray-600 text-sm line-clamp-2">{item.desc}</p>
                </CardContent>
              </Card>
            </motion.article>
          ))}
        </div>
      </div>
    </section>
  )
}

// Gallery Section
function GallerySection() {
  const galleryItems = [
    { title: 'Upacara Bendera', image: '/images/gallery/ceremony.png', span: 'md:col-span-2' },
    { title: 'Pentas Seni', image: '/images/gallery/art-performance.png', span: '' },
    { title: 'Lapangan Sekolah', image: '/images/gallery/sports-field.png', span: '' },
    { title: 'Lab Komputer', image: '/images/gallery/computer-lab.png', span: 'md:col-span-2' },
    { title: 'Perpustakaan', image: '/images/gallery/library.png', span: '' },
    { title: 'Kegiatan Kelas', image: '/images/gallery/classroom.png', span: '' },
  ]

  return (
    <section className="py-20 md:py-28 bg-gradient-to-b from-emerald-50 to-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <Badge className="bg-teal-100 text-teal-700 mb-4">Galeri</Badge>
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-gray-900 mb-4">
            Momen Berharga
          </h2>
          <p className="text-gray-600 text-lg max-w-2xl mx-auto">
            Dokumentasi kegiatan dan momen penting di SMAN 10 Kota Depok
          </p>
        </motion.div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
          {galleryItems.map((item, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.05 }}
              whileHover={{ scale: 1.02 }}
              className={`${item.span} group cursor-pointer overflow-hidden rounded-2xl relative`}
            >
              <div className="aspect-square md:aspect-video relative">
                <Image
                  src={item.image}
                  alt={item.title}
                  fill
                  className="object-cover group-hover:scale-110 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-black/0 group-hover:bg-black/40 transition-all duration-300" />
                <div className="absolute bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  <p className="text-white font-medium">{item.title}</p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}

// Contact Section
function ContactSection() {
  return (
    <section id="kontak" className="py-20 md:py-28 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12">
          {/* Contact Info */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
          >
            <Badge className="bg-emerald-100 text-emerald-700 mb-4">Kontak</Badge>
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">
              Hubungi Kami
            </h2>
            <p className="text-gray-600 mb-8">
              Silakan hubungi kami untuk informasi lebih lanjut mengenai pendaftaran, program, atau kegiatan sekolah.
            </p>

            <div className="space-y-6">
              {[
                { icon: MapPin, title: 'Alamat', content: 'Jl. Raya Sawangan No. 123, Depok, Jawa Barat 16511' },
                { icon: Phone, title: 'Telepon', content: '(021) 7788-1234' },
                { icon: Mail, title: 'Email', content: 'info@sman10depok.sch.id' },
                { icon: Clock, title: 'Jam Operasional', content: 'Senin - Jumat: 07:00 - 16:00 WIB' },
              ].map((item, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.1 }}
                  className="flex items-start gap-4"
                >
                  <div className="w-12 h-12 bg-emerald-100 rounded-xl flex items-center justify-center flex-shrink-0">
                    <item.icon className="w-5 h-5 text-emerald-600" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-900">{item.title}</h4>
                    <p className="text-gray-600">{item.content}</p>
                  </div>
                </motion.div>
              ))}
            </div>

            {/* Social Media */}
            <div className="mt-8">
              <h4 className="font-semibold text-gray-900 mb-4">Ikuti Kami</h4>
              <div className="flex gap-3">
                {[
                  { icon: Facebook, color: 'hover:bg-blue-500' },
                  { icon: Instagram, color: 'hover:bg-pink-500' },
                  { icon: Youtube, color: 'hover:bg-red-500' },
                  { icon: Twitter, color: 'hover:bg-sky-500' },
                ].map((social, index) => (
                  <motion.button
                    key={index}
                    whileHover={{ scale: 1.1 }}
                    className={`w-10 h-10 bg-gray-100 rounded-lg flex items-center justify-center text-gray-600 hover:text-white ${social.color} transition-all`}
                  >
                    <social.icon className="w-5 h-5" />
                  </motion.button>
                ))}
              </div>
            </div>
          </motion.div>

          {/* Map Placeholder */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="rounded-3xl overflow-hidden shadow-lg h-80 lg:h-auto"
          >
            <div className="w-full h-full min-h-[320px] bg-gradient-to-br from-emerald-100 to-teal-100 flex items-center justify-center relative">
              <div className="absolute inset-0 opacity-20">
                <div className="grid grid-cols-8 h-full">
                  {[...Array(64)].map((_, i) => (
                    <div key={i} className="border border-emerald-200" />
                  ))}
                </div>
              </div>
              <div className="text-center">
                <MapPin className="w-16 h-16 text-emerald-500 mx-auto mb-3" />
                <p className="text-emerald-700 font-medium">Lokasi SMAN 10 Kota Depok</p>
                <p className="text-emerald-600 text-sm">Klik untuk melihat di Google Maps</p>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  )
}

// Footer
function Footer() {
  return (
    <footer className="bg-gray-900 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid md:grid-cols-4 gap-8">
          {/* Brand */}
          <div className="md:col-span-2">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-12 h-12 bg-emerald-500 rounded-full flex items-center justify-center">
                <GraduationCap className="w-7 h-7 text-white" />
              </div>
              <div>
                <h3 className="font-bold text-xl">SMAN 10</h3>
                <p className="text-gray-400 text-sm">Kota Depok</p>
              </div>
            </div>
            <p className="text-gray-400 mb-4 max-w-md">
              Mencetak generasi unggul, berkarakter, dan berdaya saing global melalui pendidikan berkualitas.
            </p>
            <div className="flex gap-3">
              {[Facebook, Instagram, Youtube, Twitter].map((Icon, index) => (
                <button key={index} className="w-10 h-10 bg-gray-800 rounded-lg flex items-center justify-center text-gray-400 hover:bg-emerald-500 hover:text-white transition-all">
                  <Icon className="w-5 h-5" />
                </button>
              ))}
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-semibold mb-4">Tautan Cepat</h4>
            <ul className="space-y-2">
              {['Beranda', 'Tentang', 'Program', 'Fasilitas', 'Berita', 'Kontak'].map((link, index) => (
                <li key={index}>
                  <a href={`#${link.toLowerCase()}`} className="text-gray-400 hover:text-emerald-400 transition-colors">
                    {link}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="font-semibold mb-4">Kontak</h4>
            <ul className="space-y-3 text-gray-400 text-sm">
              <li className="flex items-start gap-2">
                <MapPin className="w-4 h-4 mt-1 flex-shrink-0 text-emerald-500" />
                <span>Jl. Raya Sawangan No. 123, Depok, Jawa Barat</span>
              </li>
              <li className="flex items-center gap-2">
                <Phone className="w-4 h-4 text-emerald-500" />
                <span>(021) 7788-1234</span>
              </li>
              <li className="flex items-center gap-2">
                <Mail className="w-4 h-4 text-emerald-500" />
                <span>info@sman10depok.sch.id</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-gray-800 mt-12 pt-8 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-gray-500 text-sm">
            © 2025 SMAN 10 Kota Depok. All rights reserved.
          </p>
          <p className="text-gray-500 text-sm">
            Dibuat dengan ❤️ untuk pendidikan Indonesia
          </p>
        </div>
      </div>
    </footer>
  )
}

// Scroll to Top Button
function ScrollToTop() {
  const [isVisible, setIsVisible] = useState(false)

  useEffect(() => {
    const toggleVisibility = () => {
      setIsVisible(window.scrollY > 500)
    }
    window.addEventListener('scroll', toggleVisibility)
    return () => window.removeEventListener('scroll', toggleVisibility)
  }, [])

  return (
    <AnimatePresence>
      {isVisible && (
        <motion.button
          initial={{ opacity: 0, scale: 0.5 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.5 }}
          whileHover={{ scale: 1.1 }}
          onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
          className="fixed bottom-6 right-6 w-12 h-12 bg-emerald-500 text-white rounded-full shadow-lg flex items-center justify-center hover:bg-emerald-600 transition-colors z-50"
        >
          <ChevronUp className="w-6 h-6" />
        </motion.button>
      )}
    </AnimatePresence>
  )
}

// Main Page Component
export default function Home() {
  return (
    <main className="min-h-screen flex flex-col">
      <Navbar />
      <HeroSection />
      <AboutSection />
      <ProgramsSection />
      <FacilitiesSection />
      <NewsSection />
      <GallerySection />
      <ContactSection />
      <Footer />
      <ScrollToTop />
    </main>
  )
}
