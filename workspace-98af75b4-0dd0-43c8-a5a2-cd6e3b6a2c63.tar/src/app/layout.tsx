import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "SMAN 10 Kota Depok - Sekolah Unggulan dan Berkarakter",
  description: "SMAN 10 Kota Depok, sekolah menengah atas unggulan di Kota Depok dengan kurikulum berkualitas, fasilitas modern, dan lingkungan belajar yang kondusif.",
  keywords: ["SMAN 10 Depok", "SMA Negeri 10 Depok", "Sekolah Depok", "SMA Unggulan Depok", "Pendidikan Kota Depok"],
  authors: [{ name: "SMAN 10 Kota Depok" }],
  icons: {
    icon: "/logo.svg",
  },
  openGraph: {
    title: "SMAN 10 Kota Depok - Sekolah Unggulan dan Berkarakter",
    description: "SMAN 10 Kota Depok, sekolah menengah atas unggulan di Kota Depok dengan kurikulum berkualitas, fasilitas modern, dan lingkungan belajar yang kondusif.",
    type: "website",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="id" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
